#!/bin/bash

/bin/su -c "/fred/run.sh start" - tester 
