#!/bin/sh

cd "$INSTALL_PATH"

java -jar bin/browser.jar "http://freenetproject.org/uninstall.html"
